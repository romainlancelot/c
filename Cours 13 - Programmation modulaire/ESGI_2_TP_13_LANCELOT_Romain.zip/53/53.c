// Romain LANCELOT - 2ESGI A4
// Exercice très (trop ?) dur ...

#include <stdio.h>
#include <stdlib.h>


typedef struct Node Node;
struct Node {
    char key;
    int value;
    Node * lower;
    Node * upper;
    Node * next;
    Node * prev;
};

int main() {
    

    exit(EXIT_SUCCESS);
}