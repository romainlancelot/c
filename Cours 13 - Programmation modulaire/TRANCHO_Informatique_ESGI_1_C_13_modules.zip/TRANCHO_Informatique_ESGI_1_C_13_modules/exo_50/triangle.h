/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 50.
 * Fonctionnalités publiques du module triangle
 */

#ifndef DEF_HEADER_TRIANGLE
#define DEF_HEADER_TRIANGLE

#include "point.h"

typedef struct Triangle Triangle;
struct Triangle {
	Point first;
	Point second;
	Point third;
};

Triangle Triangle_creer(Point first, Point second, Point third);

void Triangle_afficher(const Triangle * triangle);

double Triangle_perimetre(const Triangle * triangle);

#endif