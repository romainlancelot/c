/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 50.
 * Fichier d'exemple d'utilisation des modules
 */

#include <stdio.h>
#include <stdlib.h>

#include "triangle.h"

int main() {
	Triangle triangle = Triangle_creer(
		Point_creer(0, 0),
		Point_creer(4, 0),
		Point_creer(0, 3)
	);
	Triangle_afficher(&triangle);
	printf("\nPerimetre : %g\n", Triangle_perimetre(&triangle));
	exit(EXIT_SUCCESS);
}