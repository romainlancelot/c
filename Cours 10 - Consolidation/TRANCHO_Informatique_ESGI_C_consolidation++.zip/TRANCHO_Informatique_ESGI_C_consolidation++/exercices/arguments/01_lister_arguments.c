#include <stdio.h>
#include <stdlib.h>

int main(/* TODO : arguments */) {
	/* TODO : lister les arguments du programme */
	exit(EXIT_SUCCESS);
}