#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(/* TODO : arguments du programme */) {
	int first = 0;
	int second = 0;
	int x = 0, y = 0;
	/* TODO : changer les valeurs de first, second et (x, y) depuis des options */
	printf("first = %d\nsecond = %d\ncoords = (%d, %d)\n", first, second, x, y);
	exit(EXIT_SUCCESS);
}