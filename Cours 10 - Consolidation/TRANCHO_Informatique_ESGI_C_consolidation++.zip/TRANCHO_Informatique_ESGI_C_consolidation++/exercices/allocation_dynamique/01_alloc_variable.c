#include <stdio.h>
#include <stdlib.h>

int main() {
	int * variable;
	/* TODO : allouer variable et mettre son contenu à 42 */
	printf("%d\n", /* TODO : contenu de variable */);
	/* TODO : pensez à libérer variable */
	exit(EXIT_SUCCESS);
}