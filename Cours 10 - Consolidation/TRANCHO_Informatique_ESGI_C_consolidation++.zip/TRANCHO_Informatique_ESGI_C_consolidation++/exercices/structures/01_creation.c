#include <stdio.h>
#include <stdlib.h>

/* TODO : créer une structure Stats avec les champs entiers vie, attaque, defense, vitesse */

int main() {
	Stats perso;
	/* mettre la vie à 100 */
	/* mettre l'attaque à 50 */
	/* mettre la defense à 70 */
	/* mettre la vitesse à 30 */
	printf("Perso : {\n");
	printf("\tvie : %d\n", /* vie */);
	printf("\tattaque : %d\n", /* attaque */);
	printf("\tdefense : %d\n", /* defense */);
	printf("\tvitesse : %d\n", /* vitesse */);
	printf("}\n");
	exit(EXIT_SUCCESS);
}