#include <stdio.h>
#include <stdlib.h>

int main() {
	const char * chemin = "test.txt";
	/* TODO : Créer le fichier au chemin donné et y écrire "Test.\n" */
	exit(EXIT_SUCCESS);
}