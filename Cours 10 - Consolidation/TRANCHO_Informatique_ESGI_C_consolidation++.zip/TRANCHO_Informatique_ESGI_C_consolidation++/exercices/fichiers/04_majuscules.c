#include <stdio.h>
#include <stdlib.h>

int main() {
	const char * path = "exemple.txt";
	FILE * fichier = NULL;
	/* TODO : mettre en majuscules le texte au chemin donné en n'ouvrant qu'un seul fichier */
	exit(EXIT_SUCCESS);
}