#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * argv[]) {
	FILE * output = stdout;
	/* TODO : écrire le contenu des fichiers listés en arguments dans output */
	exit(EXIT_SUCCESS);
}