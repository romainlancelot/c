/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 37.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
	int mini = 0, maxi = 0;
	int nombre = 0;
	double somme = 0;
	int current;
	printf("Entrez des entiers positifs : ");
	scanf("%d", &current);
	while(current >= 0) {
		if(nombre == 0) {
			mini = current;
			maxi = current;
		} else if(current < mini) {
			mini = current;
		} else if(current > maxi) {
			maxi = current;
		}
		somme += current;
		++nombre;
		scanf("%d", &current);
	}
	if(nombre) {
		somme /= nombre;
	}
	printf("min : %d\n", mini);
	printf("max : %d\n", maxi);
	printf("moyenne : %g\n", somme);
	exit(EXIT_SUCCESS);
}