/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 41.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char * allocStr(const char * texte) {
	char * res = NULL;
	if((res = (char *)malloc((1 + strlen(texte)) * sizeof(char))) == NULL) {
		return NULL;
	}
	strcpy(res, texte);
	return res;
}

int rechercher(const char * texte, char ** noms, int taille) {
	int i;
	for(i = 0; i < taille; ++i) {
		if(strcmp(texte, noms[i]) == 0) {
			return i;
		}
	}
	return -1;
}

int main() {
	char ** noms = NULL;
	long * numeros = NULL;
	char tmpNom[50];
	long tmpNumero;
	int taille = 0, capacite = 0;
	int position;
	for(;;) {
		printf("Nom (None pour arrêter) : ");
		scanf("%s", tmpNom);
		if(strcmp(tmpNom, "None") == 0) {
			break;
		}
		printf("Numéro : ");
		scanf("%ld", &tmpNumero);
		if(taille >= capacite) {
			capacite = capacite * 2 + 10;
			if((noms = (char **)realloc(noms, capacite * sizeof(char *))) == NULL) {
				printf("Erreur allocation liste des noms\n");
				exit(EXIT_FAILURE);
			}
			if((numeros = (long *)realloc(numeros, capacite * sizeof(long))) == NULL) {
				printf("Erreur allocation liste des numeros\n");
				exit(EXIT_FAILURE);
			}
		}
		if((noms[taille] = allocStr(tmpNom)) == NULL) {
			printf("Erreur allocation nom \"%s\"\n", tmpNom);
			exit(EXIT_FAILURE);
		}
		numeros[taille] = tmpNumero;
		++taille;
	}
	for(;;) {
		printf("Nom à rechercher (None pour arrêter) :\n>>> ");
		scanf("%s", tmpNom);
		if(strcmp(tmpNom, "None") == 0) {
			break;
		}
		if((position = rechercher(tmpNom, noms, taille)) < 0) {
			printf("\"%s\" non trouvé.\n", tmpNom);
			continue;
		}
		printf("Le numéro de \"%s\" est %ld\n", tmpNom, numeros[position]);
	}
	for(--taille; taille >= 0; --taille) {
		free(noms[taille]);
	}
	free(noms);
	noms = NULL;
	free(numeros);
	numeros = NULL;
	exit(EXIT_SUCCESS);
}