/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 40.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>

void clear_grille(char grille[3][3]) {
	int i;
	for(i = 0; i < 9; ++i) {
		grille[i / 3][i % 3] = ' ';
	}
}

int finish_grille(char grille[3][3]) {
	char v = ' ';
	int i;
	int j;
	for(i = 0; i < 3; ++i) {
		if(grille[i][0] == grille[i][1] && grille[i][1] == grille[i][2]) {
			v = grille[i][0];
			break;
		}
		if(grille[0][i] == grille[1][i] && grille[1][i] == grille[2][i]) {
			v = grille[0][i];
			break;
		}
	}
	if(grille[0][0] == grille[1][1] && grille[1][1] == grille[2][2]) {
		v = grille[0][0];
	}
	if(grille[2][0] == grille[1][1] && grille[1][1] == grille[0][2]) {
		v = grille[2][0];
	}
	if(v == 'X') {
		return 1;
	}
	if(v == 'O') {
		return -1;
	}
	return 0;
}

void afficher_grille(char grille[3][3]) {
	int i;
	int j;
	for(i = 0; i < 4; ++i) {
		mvprintw(2 * i, 0, "+-+-+-+");
		if(i == 3)
			break;
		mvprintw(2 * i + 1, 0, "|%c|%c|%c|", grille[i][0], grille[i][1], grille[i][2]);
	}
}

int placer_grille(char grille[3][3], int ligne, int colonne, int joueur) {
	if(grille[ligne][colonne] != ' ') {
		return 0;
	}
	if(joueur == 1) {
		grille[ligne][colonne] = 'X';
		return 1;
	}
	if(joueur == -1) {
		grille[ligne][colonne] = 'O';
		return 1;
	}
	return 0;
}

int main() {
	char grille[3][3];
	int win;
	int joueur = 1;
	int place;
	int coups;
	initscr();
	noecho();
	cbreak();
	
	clear_grille(grille);
	
	for(coups = 0; coups < 9; ++coups) {
		clear();
		afficher_grille(grille);
		refresh();
		place = getch();
		if(place < '1' || place > '9') {
			--coups;
			continue;
		}
		place -= '1';
		if(! placer_grille(grille, 2 - place / 3, place % 3, joueur)) {
			--coups;
			continue;
		}
		joueur *= -1;
		if(win = finish_grille(grille)) {
			break;
		}
	}
	clear();
	afficher_grille(grille);
	if(win == 0) {
		mvprintw(1, 10, "Pas de gagnant");
	} else {
		mvprintw(1, 10, "Le joueur %c gagne !", (win == 1) ? 'X' : 'O');
	}
	refresh();
	getch();
	
	refresh();
	clrtoeol();
	refresh();
	endwin();
	exit(EXIT_SUCCESS);
}