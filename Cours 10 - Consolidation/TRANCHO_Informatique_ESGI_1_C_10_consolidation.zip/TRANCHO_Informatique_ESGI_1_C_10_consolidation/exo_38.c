/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 38.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
	const char * infos = "Linus Torvalds 52 ans C";
	char prenom[50];
	char nom[50];
	int age;
	char langage[50];
	sscanf(infos, "%s %s %d ans %s", prenom, nom, &age, langage);
	printf("Prenom : %s\nNom : %s\nAge : %d\nParle couramment la langue %s\n", prenom, nom, age, langage);
	exit(EXIT_SUCCESS);
}