/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 46.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>

#define M_PI 3.14159265359
#include <math.h>

typedef struct Vecteur2d Vecteur2d;
struct Vecteur2d {
	double x;
	double y;
};

Vecteur2d Vecteur2d_create(double x, double y) {
	Vecteur2d p = {x, y};
	return p;
}

Vecteur2d Vecteur2d_translation(Vecteur2d target, Vecteur2d translation) {
	target.x += translation.x;
	target.y += translation.y;
	return target;
}

Vecteur2d Vecteur2d_scale(Vecteur2d target, Vecteur2d origin, double scale) {
	target.x = scale * (target.x - origin.x) + origin.x;
	target.y = scale * (target.y - origin.y) + origin.y;
	return target;
}

Vecteur2d Vecteur2d_rotation(Vecteur2d target, Vecteur2d origin, double angleDegree) {
	Vecteur2d res;
	double angle = (angleDegree * M_PI) / 180;
	res.x = cos(angle) * (target.x - origin.x) - sin(angle) * (target.y - origin.y) + origin.x;
	res.y = sin(angle) * (target.x - origin.x) + cos(angle) * (target.y - origin.y) + origin.y;
	return res;
}

void Vecteur2d_print(Vecteur2d vec) {
	printf("(%g, %g)\n", vec.x, vec.y);
}

int main() {
	Vecteur2d p = Vecteur2d_create(0, 0);
	printf("Vecteur2d : ");
	Vecteur2d_print(p);
	p = Vecteur2d_translation(p, Vecteur2d_create(1, 2));
	printf("Translation par un Vecteur2d : ");
	Vecteur2d_print(Vecteur2d_create(1, 2));
	Vecteur2d_print(p);
	p = Vecteur2d_scale(p, Vecteur2d_create(1, 0), 0.5);
	printf("Agrandissement de rapport %g et de centre un Vecteur2d : ", 0.5);
	Vecteur2d_print(Vecteur2d_create(1, 0));
	Vecteur2d_print(p);
	p = Vecteur2d_rotation(p, Vecteur2d_create(0, 2), 135);
	printf("Rotation d'angle %d deg et de centre un Vecteur2d : ", 135);
	Vecteur2d_print(Vecteur2d_create(0, 2));
	Vecteur2d_print(p);
	exit(EXIT_SUCCESS);
}