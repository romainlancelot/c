/**
 * ESGI : Langage C avancé avec Kevin TRANCHO
 * Proposition de correction exercice 42.
 * Version code
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
	const char * sauvegarde = "compteur.txt";
	FILE * fich = NULL;
	int count = 0;
	if((fich = fopen(sauvegarde, "r")) != NULL) {
		fscanf(fich, "%d", &count);
		fclose(fich);
		fich = NULL;
	}
	if((fich = fopen(sauvegarde, "w+")) == NULL) {
		fprintf(stderr, "Erreur ouverture \"%s\"\n", sauvegarde);
		exit(EXIT_FAILURE);
	}
	++count;
	printf("Programme lancé %d fois\n", count);
	fprintf(fich, "%d\n", count);
	fclose(fich);
	fich = NULL;
	exit(EXIT_SUCCESS);
}